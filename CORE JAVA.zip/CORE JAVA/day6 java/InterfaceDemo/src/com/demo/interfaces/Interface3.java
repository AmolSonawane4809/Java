package com.demo.interfaces;

public interface Interface3 {
int m31();
void m32();
}
