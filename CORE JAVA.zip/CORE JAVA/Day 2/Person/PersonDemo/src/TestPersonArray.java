
public class TestPersonArray {


	public static void main(String[] args)
	 {
	
		Person[] ob=new Person[3];
		PersonService.acceptPesrsondata(ob);
		PersonService.displayPersondata(ob);
		
		Person q=PersonService.searchPerson(ob,id)
	}

}
	